import { User } from './user';
export class MainUser {
    token: string;
    user: User;
}