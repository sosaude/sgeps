import { Seccao } from './seccao';
export class Role {
    codigo: number;
    id?:number;
    role:String;
    seccao:Seccao;
    seccao_id: number;
}