export class Seccao {
    code: number;
    id?:number;
    nome:String;
}