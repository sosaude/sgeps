export const URL = {
  // 
      url: 'https://devbackend.marrar.co.mz/ifarmacias_backend/public/api', // DEV
      // url: 'http://ifarmacias_backend.test/api', // LOCAL
      //  url: 'https://sgepsapi.smartbp.net/public/api' //PROD
  } 